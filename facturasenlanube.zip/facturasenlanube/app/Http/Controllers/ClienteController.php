<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cliente;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;


class ClienteController extends Controller
{
    public function listaClientes(){
        $listaClientes = DB::table('clientes')->get(); 
        return json_encode( $listaClientes);  
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = DB::table('clientes')->orderBy('nombre')->paginate(6);
        return view ('clientesListar', ['clientes'=> $clientes]); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('clientesCrear');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validador = Validator::make(Input::all(), $this->reglas(), $this->mensajes());

        if ($validador->fails()){
            return redirect()->back()/*Redirect::to('clientes')*/
                    ->withErrors($validador)
                    ->withInput();
        }else{
            $cliente = new Cliente;
            $cliente->nombre = Input::get('nombre');
            $cliente->telefono = Input::get('telefono');
            $cliente->email = Input::get('email');
            $cliente->direccion = Input::get('direccion');
            $cliente->cif_nif = Input::get('cif_nif');
            $cliente->save();

            return redirect('clientes'); /*muestra el listado de clientes*/
        }   

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $field
     * @return \Illuminate\Http\Response
     */
    public function sort($field)
    {
        $clientes = DB::table('clientes')
                  ->orderBy($field)->paginate(6);

        return view ('clientesListar', ['clientes'=> $clientes]); 
    }
    

    public function search(Request $request)
    {
        $data = $request->get('buscarCliente');
        $clientes = DB::table('clientes')
                  ->where('nombre', 'like ', '%'.$data.'%')
                  ->orWhere('telefono', 'like ', '%'.$data.'%')
                  ->orwhere('email', 'like', '%'.$data.'%')
                  ->orWhere('direccion', 'like' , '%'.$data.'%')
                  ->orWhere('cif_nif', 'like', '%'.$data.'%')
                  ->orderBy('nombre')->paginate(6);
        return view ('clientesListar', ['clientes'=> $clientes]); 
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
            $cliente = Cliente::find($id) ;
          
            return view ('clientesEditar')->with('cliente', $cliente);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validador = Validator::make(Input::all(), $this->reglas(), $this->mensajes());

        if ($validador->fails()){
            return redirect()->back()/*Redirect::to('clientes')*/
                    ->withErrors($validador)
                    ->withInput();
        }else{
            $cliente = Cliente::find($id);
            $cliente->nombre = Input::get('nombre');
            $cliente->telefono = Input::get('telefono');
            $cliente->email = Input::get('email');
            $cliente->direccion = Input::get('direccion');
            $cliente->cif_nif = Input::get('cif_nif');
            $cliente->save();

            return redirect('clientes'); /*muestra el listado de clientes*/
        }   


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     
        Cliente::find($id)->delete();
        return back();/*->withMessage('seguro de borrar?');*/
        
    }

    protected function reglas(){
            return array(
            'nombre' => 'required|max:255',
            'telefono' => 'required|numeric|regex:/[0-9]{9}/',
            'email' => 'required|email',
            'direccion' => 'max:255');
    }

    protected function mensajes(){
        return array(
            'nombre.required' => 'Campo requerido',
            'nombre.max' => 'Maximo 255 caracteres',
            'telefono.required' => 'Ingrese el número de teléfono',
            'telefono.numeric' => 'Valor iválido para teléfono',
            'telefono.regex' => 'Teléfono debe tener 9 caracteres',
            'email.required' => 'Campo e-mail es requerido',
            'email.email' => 'Formato incorrecto para email');
    
    }
}
