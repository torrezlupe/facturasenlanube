angular.module("tablaApp",[], function($interpolateProvider) {
	$interpolateProvider.startSymbol('[[');
	$interpolateProvider.endSymbol(']]');
})

/*app.controller('tablaController', [ '$http', '$scope', function($http, $scope){

  $scope.clientes = [];
  $scope.totalPages = 0;
  $scope.currentPage = 1;
  $scope.range = [];

  $scope.getPosts = function(pageNumber){

    if(pageNumber===undefined){
      pageNumber = '1';
    }
//    $http.get('listaClientes?page='+pageNumber).success(function(response) {
	$http({
		method:'GET', 
		url:'listaClientes'
	}).then(function(result){//success(function(data, status, headers, config) {
			$scope.clientes = result.data;
			$scope.totalPages   = response.last_page;
      		$scope.currentPage  = response.current_page;

      // Pagination Range
      var pages = [];

      for(var i=1;i<=response.last_page;i++) {          
        pages.push(i);
      }

      $scope.range = pages; 

			console.log(result.data);
	},function(result){
			console.log(result);
	});

      //$scope.clientes        = response.data;

  };


}]);*/

	/*.factory('Post', function($resource){
		return $resource('post');
	})
	*/
	.config(['$routeProvider', function ($routeProvider){
		$routeProvider.
			when ('/',{
				templateUrl: 'templates/home.html',
				controller: 'AdminController'
			}).
			when('/clientes', {
				templateUrl:'templates/clientes.html',
				controller: 'ClienteController'
			});

	}])

	.value('apiUrl', 'public path url')
	/*.service('Post'. {$resouce, function($resource){
		return $resource('listaClientes',{id:'@id'});
	}})
*/

	.controller('AdminController', function($scope, $http){
		$scope.pools = [];
	})

	.controller('tablaController', ['$http', '$scope', 'dataFactory', 'apiUrl', function($http, $scope, dataFactory, apiUrl){
	/*$scope.sortType ='nombre';
	$scope.sortReverse ='false';
	$scope.buscarCliente ='';
	$scope.clientes=[];

	$scope.totalPages=0;
	$scope.currentPage =1;
	$scope.range = [];*/

		$scope.data = [];
		$scope.libraryTemp = {};
		$scope.totalProductsTempo = {};

		$scope.totalProducts = 0;
		$scope.pageChanged = function (newPage){
			getResultsPage(newPage);
		};

		getResultsPage(1);

  getResultsPage(1);
  function getResultsPage(pageNumber) {
      if(! $.isEmptyObject($scope.libraryTemp)){
          dataFactory.httpRequest(apiUrl+'clientes?search='+$scope.searchInputText+'&page='+pageNumber).then(function(data) {
            $scope.data = data.data;
            $scope.totalProducts = data.total;
          });
      }else{
        dataFactory.httpRequest(apiUrl+'clientes?page='+pageNumber).then(function(data) {
          console.log(data);
          $scope.data = data.data;
          $scope.totalProducts = data.total;
        });
      }
  }
  $scope.dbSearch = function(){
      if($scope.searchInputText.length >= 3){
          if($.isEmptyObject($scope.libraryTemp)){
              $scope.libraryTemp = $scope.data;
              $scope.totalProductsTemp = $scope.totalProducts;
              $scope.data = {};
          }
          getResultsPage(1);
      }else{
          if(! $.isEmptyObject($scope.libraryTemp)){
              $scope.data = $scope.libraryTemp ;
              $scope.totalProducts = $scope.totalProductsTemp;
              $scope.libraryTemp = {};
          }
      }
  }
  $scope.saveAdd = function(){
    dataFactory.httpRequest('clientes','POST',{},$scope.form).then(function(data) {
      $scope.data.push(data);
      $(".modal").modal("hide");
    });
  }
  $scope.edit = function(id){
    dataFactory.httpRequest(apiUrl+'clientes/'+id+'/edit').then(function(data) {
        console.log(data);
          $scope.form = data;
    });
  }
  $scope.updateProduct = function(){
    dataFactory.httpRequest(apiUrl+'clientes/'+$scope.form.id,'PUT',{},$scope.form).then(function(data) {
          $(".modal").modal("hide");
        $scope.data = apiModifyTable($scope.data,data.id,data);
    });
  }
  $scope.remove = function(product,index){
    var result = confirm("Are you sure delete this product?");
       if (result) {
      dataFactory.httpRequest(apiUrl+'clientes/'+product.id,'DELETE').then(function(data) {
          $scope.data.splice(index,1);
      });
    }
  }
   
};


/*	$scope.getPosts = function(pageNumber){
		console.log('dentro del scope.getPoast');
		console.log('pageNumber:'+pageNumber);
		if(pageNumber === undefined){
			pageNumber = 1;
		}

		//Post.get({page: pageNumber}, function(result){
		$http({
			method:'GET', 
			url:'listaClientes/'+$scope.sortType+'?page='+pageNumber
			}).then(function(result){	
				
				$scope.clientes =result.data.data;
				$scope.totalPages = result.data.last_page;
				$scope.currentPage =result.data.current_page;
				console.log('DENTRO DEL POST.get');
				console.log(result);
				console.log(result.data);
				console.log(result.data.data);
				console.log('total_pages:' + result.data.last_page);
				console.log('current_page:' + result.data.current_page);

				var pages= [];
				for(var i=1; i<=result.data.last_page; i++){
					pages.push(i);
				}

				$scope.range = pages;
				alert($scope.range);
			},function(result){
			console.log(result);
		}); 
	  //})
	};
*/
	
	/*$http({
		method:'GET', 
		url:'listaClientes/'+$scope.sortType+'?page='+pageNumber
	}).then(function(result){//success(function(data, status, headers, config) {
			$scope.clientes = result.data.data;
			$scope.totalPages = result.data.last_page;
			$scope.currentPage =result.data.current_page;
			console.log(result);
			console.log(result.data);
			console.log(result.data.data);
			console.log('total_pages:' + result.data.last_page);
			console.log('current_page:' + result.data.current_page);

			var pages= [];
			for(var i=1; i<=result.data.last_page; i++){
				pages.push(i);
			}
			
			$scope.range = pages;
			console.log('range:' + $scope.range);

	},function(result){
			console.log(result);
	}); */
	

	$scope.getPosts();
}])

	.directive('tablePagination', function($compile) {
    //function tablePagination(//) {
     return{
        restrict: 'E',
        scope: {text: '@'},
        template: '<ul class="pagination">'+
          '<li ng-show="currentPage != 1"><a href="javascript:void(0)" ng-click="getPosts(1)">«</a></li>'+
          '<li ng-show="currentPage != 1"><a href="javascript:void(0)" ng-click="getPosts(currentPage-1)">‹ Prev</a></li>'+
          '<li ng-repeat="i in range" ng-class="{active : currentPage == i}">'+
              '<a href="javascript:void(0)" ng-click="getPosts(i)">{{i}}</a>'+
          '</li>'+
          '<li ng-show="currentPage != totalPages"><a href="javascript:void(0)" ng-click="getPosts(currentPage+1)">Next ›</a></li>'+
          '<li ng-show="currentPage != totalPages"><a href="javascript:void(0)" ng-click="getPosts(totalPages)">»</a></li>'+
        '</ul>'
     };
  });
	/*$scope.clientes = [
		{nombre: 'Lupe Torrez', telefono: '664065826', email:'torrezlupe@yahoo.com', direccion:'Av. Doctor Marañon 31', cif_nif:'887799776'},
		{nombre: 'Andrea Condoretty', telefono: '664065826', email:'torrezlupe@yahoo.com', direccion:'Calle alamos1', cif_nif:'6666676'},
		{nombre: 'Gabriel condoretty', telefono: '689898767', email:'gabriel@GMAIL.com', direccion:'', cif_nif:''},
		{nombre: 'Carla Condoretty', telefono: '111111111', email:'carla@yahoo.com', direccion:'Calle Compas de la Victoria', cif_nif:''},
		{nombre: 'Merwin Condoretty', telefono: '222222222', email:'a.condoretty@gmail.com', direccion:'', cif_nif:'888888996'},
		{nombre: 'Ana GaRCIA', telefono: '666666666', email:'torrezlupe@yahoo.com', direccion:'Av. Doctor Marañon 31', cif_nif:''}
		];*/
//});


/*var tablaApp = angular.module('tablaApp', ['tablaController', 'tablaService'], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
});*/
