angular.module("tablaApp",[], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
})
	
	.controller('tablaController', function($scope, $http){
	$scope.sortType ='nombre';
	$scope.sortReverse ='false';
	$scope.buscarcliente ='';
	$scope.clientes=[];

	$http({
		method:'GET', 
		url:'listaClientes'
	}).then(function(result){//success(function(data, status, headers, config) {
			$scope.clientes = result.data;
			console.log(result.data);
	},function(result){
			console.log(result);
	});

});
	/*$scope.clientes = [
		{nombre: 'Lupe Torrez', telefono: '664065826', email:'torrezlupe@yahoo.com', direccion:'Av. Doctor Marañon 31', cif_nif:'887799776'},
		{nombre: 'Andrea Condoretty', telefono: '664065826', email:'torrezlupe@yahoo.com', direccion:'Calle alamos1', cif_nif:'6666676'},
		{nombre: 'Gabriel condoretty', telefono: '689898767', email:'gabriel@GMAIL.com', direccion:'', cif_nif:''},
		{nombre: 'Carla Condoretty', telefono: '111111111', email:'carla@yahoo.com', direccion:'Calle Compas de la Victoria', cif_nif:''},
		{nombre: 'Merwin Condoretty', telefono: '222222222', email:'a.condoretty@gmail.com', direccion:'', cif_nif:'888888996'},
		{nombre: 'Ana GaRCIA', telefono: '666666666', email:'torrezlupe@yahoo.com', direccion:'Av. Doctor Marañon 31', cif_nif:''}
		];*/
//});


/*var tablaApp = angular.module('tablaApp', ['tablaController', 'tablaService'], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
});*/
