@extends('layouts.main_layout')

@section('content')

<div class="container" ng-app="tablaApp" ng-controller="tablaController" ng-init="getPost()">

<form class="form-inline" action="" method="post">
	<div class="input-group pull-right mb-4 mr-sm-4 mb-sm-0">
      
	  <div class="input-group mb-2 mr-sm-2 mb-sm-0 ">
	  		<input type="text" class="form-control" name="nombre" placeholder="Buscarcliente" ng-model="buscarCliente" >
	  		<div class="input-group-addon"><i class="fa fa-search"></i></div>
	  </div>
      <a href="{{action('ClienteController@create')}}" class="btn btn-primary">Nuevo</a>     
	</div>
</form>

<div class="row form-group"></div>	
 
<table id="clientes" class="table table-hover table-striped table-bordered" >
    <thead>
        <tr>
            <th> <a href="#" ng-click="sortType='nombre'">Nombre 
                <span ng-show="sortType=='nombre'" class="fa fa-caret-down"></span></a></th>
            <th><a href="#" ng-click="sortType='telefono'">Teléfono 
                <span ng-show="sortType=='telefono'" class="fa fa-caret-down"></spamn></a></th>
            <th><a href="#" ng-click="sortType='email'">E-mail 
                <span ng-show="sortType=='email'" class="fa fa-caret-down"></sn></a></th>
            <th><a href="#" ng-click="sortType='direccion'">Dirección 
                <span ng-show="sortType=='direccion'" class="fa fa-caret-down"></spn></a></th>
            <th><a href="#" ng-click="sortType='cif_nif'">CIF 
                <span ng-show="sortType=='cif_nif'" class="fa fa-caret-down"></spn></a></th>
            <th></th>
            <th></th>
        </tr>
    </thead>
<!--     <tfoot>
        <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>E-mail</th>
            <th>Dirección</th>
            <th>CIF</th>
        </tr>
    </tfoot>
 -->    <tbody>
        
        <tr ng-repeat="client in clientes">  <!--dir-paginate="value in data |itemsPerPage:6" total-items="totalItems">  -->
            <td> [[ client.nombre ]]</td>
            <td> [[ client.telefono ]]</td>
            <td> [[ client.email ]]</td>
            <td> [[ client.direccion ]]</td>
            <td> [[ client.cif_nif ]]</td>
            
        </tr>

    </tbody>
 
</table>

<table-pagination></table-pagination>
<!--  {{ $clientes->links()}}
 -->
</div>

@endsection

@section('scripts')
	
<script>
function confirmarBorrado(){
	var result= confirm('seguro de borrar al cliente seleccionado?' );
	if (result){
		return true;
	}else{
		return false;
	}
}
</script>
@endsection