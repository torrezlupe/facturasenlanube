@extends('layouts.main_layout')

@section('content')

<div class="container">

<form class="form-inline" action="{{action('ClienteController@search')}}" method="post">
{{csrf_field()}}
	<div class="input-group pull-right mb-4 mr-sm-4 mb-sm-0">
      
	  <div class="input-group mb-2 mr-sm-2 mb-sm-0 ">
	  		<input type="text" class="form-control" name="buscarCliente" placeholder="Buscar cliente">   
	  		<div class="input-group-addon"><button type="submit" class="btn btn-link btn-xs"><i class="fa fa-search"></i></button></div>
	  </div>
      <a href="{{action('ClienteController@create')}}" class="btn btn-primary">Nuevo</a>     
	</div>
</form>

<div class="row form-group"></div>	
 
    <table id="tablaClientes" class="table table-hover table-striped table-bordered" width="100%">
        <thead>
            <tr>
                <th> <a href="{{action('ClienteController@sort', ['nombre'])}}" >Nombre 
                    <span ng-show="sortType=='nombre'" class="fa fa-caret-down"></span></a></th>
                <th><a href="{{action('ClienteController@sort', ['telefono'])}}" >Teléfono 
                    <span ng-show="sortType=='telefono'" class="fa fa-caret-down"></spamn></a></th>
                <th><a href="{{action('ClienteController@sort', ['email'])}}" >E-mail 
                    <span ng-show="sortType=='email'" class="fa fa-caret-down"></sn></a></th>
                <th><a href="{{action('ClienteController@sort', ['direccion'])}}" >Dirección 
                    <span ng-show="sortType=='direccion'" class="fa fa-caret-down"></spn></a></th>
                <th><a href="{{action('ClienteController@sort', ['cif_nif'])}}">CIF 
                    <span ng-show="sortType=='cif_nif'" class="fa fa-caret-down"></spn></a></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
<!--     <tfoot>
        <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>E-mail</th>
            <th>Dirección</th>
            <th>CIF</th>
        </tr>
    </tfoot>-->    
 
          <tbody>
        	@foreach($clientes as $cliente)
            <tr>
                <td>{{$cliente->nombre}}</td>
                <td>{{$cliente->telefono}}</td>
                <td>{{$cliente->email}}</td>
                <td>{{$cliente->direccion}}</td>
                <td>{{$cliente->cif_nif}}</td>
                <td><a href="{{action('ClienteController@edit', ['cliente'=>$cliente->id])}}">
                	<button type="submit"><i class="fa fa-pencil"></i></button> </a></td>
                <td><a href="{{action('ClienteController@destroy', ['id'=>$cliente->id])}}" onclick="return confirmarBorrado('{{$cliente->nombre}}')"><i class="fa fa-times"></i></a</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    {{ $clientes->links()}}

</<div>

@endsection

@section('scripts')
<script>
function confirmarBorrado(cliente)
{
    var result= confirm('seguro borrar al cliente: ' + cliente  + '?');
    if (result){
        return true;
    }else{
        return false;
    }            
}
</script>
@endsection