@extends('layouts.main_layout')

@section('content')

    <form class="well form-horizontal" action="{{action('ClienteController@update', ['id'=>$cliente->id])}}" method="post">
    {{csrf_field()}}
    <input type="hidden" name="_method" value="put">
		<fieldset>

		<legend>Editar cliente</legend>		

		<div class="form-group">
		  <label class="col-md-4 control-label">Nombre completo</label>  
		  <div class="col-md-4  inputGroupContainer">
		  	@if ($errors->has('nombre')) 
		  		<input  name="nombre" placeholder="Nombre del cliente" class="form-control" type="text" value="{{old('nombre')}}">
		  		<div class="alert alert-danger">{{$errors->first('nombre')}}</div> 
		  	@else
		  		<input  name="nombre" placeholder="Nombre del cliente" class="form-control" type="text" value="{{$cliente->nombre}}">
		  	@endif
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-md-4 control-label" >Teléfono</label> 
		    <div class="col-md-4 inputGroupContainer">
		    @if ($errors->has('telefono'))
		  		<input name="telefono" placeholder="Telefono del cliente" class="form-control"  type="text" value="{{old('telefono')}}">
		  		<div class="alert alert-danger">{{$errors->first('telefono')}}</div> 
		  	@else
		  		<input name="telefono" placeholder="Telefono del cliente" class="form-control"  type="text" value="{{$cliente->telefono}}">
		  	@endif
			</div>
		</div>

		<div class="form-group">
		  	<label class="col-md-4 control-label">E-Mail</label>  
		  	<div class="col-md-4 inputGroupContainer">
		  	@if ($errors->has('email'))
			  	<input name="email" placeholder="E-Mail del cliente" class="form-control"  type="text" value="{{old('email')}}">
			  	<div class="alert alert-danger">{{$errors->first('email')}}</div>
			@else
				<input name="email" placeholder="E-Mail del cliente" class="form-control"  type="text" value="{{$cliente->email}}">
			@endif
		    </div>
		</div>
		       
		<div class="form-group">
		  	<label class="col-md-4 control-label">Direccion</label>  
		  	<div class="col-md-4 inputGroupContainer">
		  	@if ($errors->has('direccion'))
				<input name="direccion" placeholder="Dirección del cliente" class="form-control" type="text" value="{{old('direccion')}}">
				 <div class="alert alert-danger">{{$errors->first('direccion')}}</div>
			@else
				<input name="direccion" placeholder="Dirección del cliente" class="form-control" type="text" value="{{$cliente->direccion}}">
			@endif
		    </div>
		</div>

		<div class="form-group">
		  <label class="col-md-4 control-label">CIF</label>  
		  <div class="col-md-4 inputGroupContainer">
		 	@if ($errors->has('cif')) 
			  <input name="cif_nif" placeholder="CIF o NIF del cliente" class="form-control"  type="text" value="{{old('cif')}}">
			  <div class="alert alert-danger">{{$errors->first('cif')}}</div>
		  	@else	
		  		<input name="cif_nif" placeholder="CIF o NIF del cliente" class="form-control"  type="text" value="{{$cliente->cif_nif}}">
		  	@endif
		  </div>
		</div>

		<!-- Button -->
		<div class="form-group">
		  <label class="col-md-4 control-label"></label>
		  <div class="col-md-4">
		    <button type="submit" class="btn btn-primary" >Guardar</button>
		    <a href="{{URL::to('clientes')}}" class="btn btn-primary">Cancelar</a> 
		  </div>
		</div>
	</fieldset>
	</form>

@endsection