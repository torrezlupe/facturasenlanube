@extends('layouts.main_layout')

@section('content')

    <form class="well form-horizontal" action="{{action('ClienteController@store')}}" method="post">
    {{csrf_field()}}
		<fieldset>

		<legend>Registro de cliente</legend>		
		
		<div class="form-group">
		  <label class="col-md-4 control-label">Nombre completo</label>  
		  <div class="col-md-4  inputGroupContainer">
		  		<input  name="nombre" placeholder="Nombre del cliente" class="form-control"  type="text" value="{{old('nombre')}}">
		  		@if ($errors->has('nombre')) <div class="alert alert-danger">{{$errors->first('nombre')}}</div> @endif
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-md-4 control-label" >Teléfono</label> 
		    <div class="col-md-4 inputGroupContainer">
		  		<input name="telefono" placeholder="Telefono del cliente" class="form-control"  type="text" value="{{old('telefono')}}">
		  		@if ($errors->has('telefono')) <div class="alert alert-danger">{{$errors->first('telefono')}}</div> @endif
			</div>
		</div>

		<div class="form-group">
		  	<label class="col-md-4 control-label">E-Mail</label>  
		  	<div class="col-md-4 inputGroupContainer">
			  	<input name="email" placeholder="E-Mail del cliente" class="form-control"  type="text" value="{{old('email')}}">
			  	@if ($errors->has('email')) <div class="alert alert-danger">{{$errors->first('email')}}</div> @endif
		    </div>
		</div>
		       
		<div class="form-group">
		  	<label class="col-md-4 control-label">Direccion</label>  
		  	<div class="col-md-4 inputGroupContainer">
				<input name="direccion" placeholder="Dirección del cliente" class="form-control" type="text" value="{{old('direccion')}}">
				@if ($errors->has('direccion')) <div class="alert alert-danger">{{$errors->first('direccion')}}</div> @endif
		    </div>
		</div>

		<div class="form-group">
		  <label class="col-md-4 control-label">CIF</label>  
		  <div class="col-md-4 inputGroupContainer">
			  <input name="cif_nif" placeholder="CIF o NIF del cliente" class="form-control"  type="text" value="{{old('cif')}}">
			  @if ($errors->has('cif')) <div class="alert alert-danger">{{$errors->first('cif')}}</div> @endif
		  </div>
		</div>

		<!-- Success message
		<div class="alert alert-success" role="alert" id="success_message">Cliente registrado correctamente.</div>  -->

		<!-- Button -->
		<div class="form-group">
		  <label class="col-md-4 control-label"></label>
		  <div class="col-md-4">
		    <button type="submit" class="btn btn-primary" >Registrar</button>
		    <a href="{{URL::to('clientes')}}" class="btn btn-primary">Cancelar</a> 
		  </div>
		</div>
			  
		</fieldset>
	</form>

@endsection