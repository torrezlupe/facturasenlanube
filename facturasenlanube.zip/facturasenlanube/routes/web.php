<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();

Route::get('/', 'HomeController@index');

Route::group(['middleware' => ['auth']], function(){

        Route::resource('clientes', 'ClienteController');

        Route::get('borrarCliente/{id}', 'ClienteController@destroy');

        Route::get('crearCliente', 'ClienteController@create');

        Route::get('editarCliente/{id}','ClienteController@edit');

        Route::post('buscarCliente','ClienteController@search');

        Route::get('ordenarCliente/{field}', 'ClienteController@sort');

        Route::get('listaClientes/{sortType}', array('as' => 'listaclientes', 'uses' => 'ClienteController@listaClientes'));

        Route::get('dashboard', function(){
            return view('dashboard');
        });
});
//'ClienteController@listaClientes');



/*Route::get('/', function () {

    return view('app');

});*/

Route::group(['middleware' => ['web']], function () {

    Route::resource('items', 'ItemController');

});

// Templates

Route::group(array('prefix'=>'/templates/'),function(){

    Route::get('{template}', array( function($template)

    {

        $template = str_replace(".html","",$template);

        View::addExtension('html','php');

        return View::make('templates.'.$template);

    }));

});
/*&Route::group(['middleware' => ['web']], function () {
    Route::resource('products', 'ProductController');
});
// Angular HTML Templates
Route::group(array('prefix'=>'/htmltemplates/'),function(){
    Route::get('{htmltemplates}', array( function($htmltemplates)
    {
        $htmltemplates = str_replace(".html","",$htmltemplates);
        View::addExtension('html','php');
        return View::make('htmltemplates.'.$htmltemplates);
    }));
});*/
